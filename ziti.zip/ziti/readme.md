## 库介绍
本库为corepress主题提供部分CDN加速，通过https://www.jsdelivr.com/ 加速
有些资源库，前端CDN并没有提供，所以得自己做，现在较好的方案就是使用jsdelivr来加速github。
小水管主机可以用这个，大水管完全可以忽略。

